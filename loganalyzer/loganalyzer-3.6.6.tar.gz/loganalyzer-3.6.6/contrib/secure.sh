#!/bin/sh
chmod 644 config.php
